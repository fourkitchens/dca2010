<?php 
  
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php print $language->language ?>" lang="<?php print $language->language ?>" dir="<?php print $language->dir ?>">
  <head>
    <title>Something</title>
    <?php print $styles; ?>
  </head>

  <body>

    <?php if (!empty($logo)): ?>
      <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" id="logo">
        <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
      </a>
    <?php endif; ?>
  
    <h1 id="site-name"><a href="<?php print $front_page ?>" title="<?php print t('Home'); ?>" rel="home"><?php print $site_name; ?></a></h1>
  
    <div id="site-slogan"><?php print $site_slogan; ?></div>
    
    <h1><?php print $title; ?></h1>
    
    <div id="sidebar"><?php print $sidebar; ?></div>
    
    <div id="content"><?php print $content; ?></div>
    
    <?php print $footer; ?>
  
  </body>
  
</html>