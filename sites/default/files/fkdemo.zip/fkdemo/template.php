<?php
/**
 * Override or insert variables into the node templates.
 *
 * @param $vars
 *   An array of variables to pass to the theme template.
 * @param $hook
 *   The name of the template being rendered ("node" in this case).
 */
function fkdemo_preprocess_page(&$vars) {
  $node = $vars['node'];
  
    //suggest a new page template
    //$vars['template_files'][] = 'sammich';
    
}
   
function fkdemo_preprocess_node(&$vars) {
  $node = $vars['node'];
  
  //switch page templates in the case of this content type
  
  if ($node->type == 'sammich') {
    
    //krumo($vars);
    
  } 

  
}

